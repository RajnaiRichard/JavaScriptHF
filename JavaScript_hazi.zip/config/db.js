var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/sfhuf8');

module.exports = mongoose;